//import {printCharacterDetail} from 'details.js';


/*Al hacer click en el boton de lista nos lleva aquí, añadimos un eventListener y llamamos a getData para obtener los datos
de los distintos personajes*/
window.addEventListener('load', () => {
	document.getElementById('listButton').addEventListener('click', () => {
		getData('character/', printData)
	});
})

/*Mediante esta función obtenemos el json de la API para poder trabajar con el e imprimir sus datos*/
function getData(section, callback){
	//console.log('https://rickandmortyapi.com/api/' + section);
	fetch(`https://rickandmortyapi.com/api/${section}`)
	.then(response => {
		return response.json();
	})
	.then(myJson => {
		//console.log(myJson);
		callback(myJson.results);
	});
}

/*Con esta función imprimimos la imagen y el nombre de cada personaje, se corresponde con la vista de list */
function printData(response){
	//let characters = response.result;
	
	let divout=document.getElementById('outxt');
	let out ="";

	for(var k in response){

		out+=`<p> ${response[k].name}</p><br />` ;

		out+=`<img id="character-${k}" src="${response[k].image}"><hr />` ;

		divout.innerHTML = out; //indexo info al html para mostrarlo

		/*document.getElementById(`character-${k}`).addEventListener('click', () => {
			//debugger;
			printCharacterDetail(response[k])
		});*/
	}
	
	/*añadimos un addeventlistener para que se muestre más información 
	de un personaje si se pincha sobre la foto*/
	for(let i in response){ 
		let a = document.querySelectorAll(`img#character-${i}`);

		//queryselectorall para seleccionar todos los personajes y añadirle el event
		document.querySelectorAll(`img#character-${i}`)[0].addEventListener('click', () => { 
			//debugger;
			printCharacterDetail(response[i])
		});
	}

}

/*Mediante esta función imprimimos los detalles de cada personaje
en el que se pinche*/
function printCharacterDetail(characterDetail){
	//debugger;
    let divout1=document.getElementById('outxt');
	let out1 ="";

    out1+= `<p> <img src="${characterDetail.image}"><hr /></p>`;
	out1+= `<p> Name: ${characterDetail.name} </p>`;
    out1+= `<p> Status: ${characterDetail.status} </p>`;
    out1+= `<p> Specie: ${characterDetail.species} </p>`;
    out1+= `<p> Type: ${characterDetail.type} </p>`;
    out1+= `<p> Gender: ${characterDetail.gender} </p>`;

    divout1.innerHTML = out1;
}