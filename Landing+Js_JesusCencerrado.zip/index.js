// Variable global que nos dirá si hemos dado un click al botón
var clicando= false;

var timeoutID;

function saludoen2seg(){
	timeoutID = setTimeout(showAlert,2000);
}

function showAlert(){
	alert("Welcome");
}

saludoen2seg();
